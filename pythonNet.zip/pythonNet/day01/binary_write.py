"""
    以二进制方式写入
"""

fd = open('test','wb')
fd.write(b"hello world\n")#字节串
fd.write(b"hi!")#字节串

fd.close()