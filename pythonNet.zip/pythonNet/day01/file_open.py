"""
    文件操作示例
"""
n=int(raw_input(u"请输入一个正整数：".encode("gbk")))
res=[]
res.append(str(n%2))
while n/2!=0:
    n=n/2
    res.append(str(n%2))
res.reverse()
print(u"转化为二进制是：","".join(res))