"""
    文件偏移量示例
"""

fd = open('test','r+')

print(fd.tell())
print(fd.read(2))
print(fd.tell())
fd.seek(5,0)
print(fd.read(2))
print(fd.fileno())





fd.close()