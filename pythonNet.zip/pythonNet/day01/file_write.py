
fd = open('test','w+')




fd.write("hello 死鬼\n")
fd.write("干哈呀")

fd.writelines(["asdad\n","sjdnf\n","ksufsf\n"])

data = fd.read()
print(data)
fd.close()
