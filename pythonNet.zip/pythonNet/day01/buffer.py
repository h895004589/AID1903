"""
    缓冲区示例
"""

# fd = open('test','w',0) 无缓冲(不允许)

# fd = open('test','w',12) 行缓冲

# fd = open('test','w',12) 指名缓冲区大小(不识别)

fd = open('test','w') #系统默认缓冲区的大小
while True:
    s = input(">>")
    if s == "q":
        break
    fd.write(s+"\n")
    fd.flush()
fd.close()
