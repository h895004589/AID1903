"""
    以二进制方式打开
"""

fd = open('test','rb')
data = fd.read()#字节串
print(data.decode())


fd.close()