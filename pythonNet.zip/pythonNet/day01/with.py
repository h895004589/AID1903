
with open('test','r') as f:
    data = f.read()
    print(data)