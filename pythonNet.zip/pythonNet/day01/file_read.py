

# fd = open('test','r')
#
# data = fd.readline()
# print("读取文件:",data)
#
# fd.close()

# fd = open('test','r')
#
# data = fd.readlines()
# print("读取文件:",data)
#
# fd.close()

fd = open('test','r')

for line in fd:
    print("每行内容:",line)

fd.close()
