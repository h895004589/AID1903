# s = input(">>")
#
# print("str:", s)

list01 = [1,2,3,6,1,2]

for l in range(len(list01)-1):
    for i in range(l+1,len(list01)):
        if list01[l] == list01[i]:
            del list01[i]

print(list01)