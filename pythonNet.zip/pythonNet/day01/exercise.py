

input_path = input("请输入文件路径: ")

with open(input_path, 'rb') as fd:
    file_read = fd.read()

input_file_name = input("请输入文件名字: ")
with open(input_file_name, 'wb') as wd:
    wd.write(file_read)
