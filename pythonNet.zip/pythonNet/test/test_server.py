
from socket import *

sockfd = socket(AF_INET,SOCK_DGRAM)

sockfd.bind(('127.0.0.1',8080))

while True:
    data,addr = sockfd.recvfrom(1024)
    if not data:
        break
    print("收到的消息为: ",data.decode())
    sockfd.sendto(data,addr)

sockfd.close()
