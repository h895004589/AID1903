
from socket import *

sockfd = socket(AF_INET,SOCK_DGRAM)

connect_addr = ('127.0.0.1',8080)

while True:
    data = input("请输入信息: ")
    if not data:
        break
    sockfd.sendto(data.encode(),connect_addr)
    receive_data,addr = sockfd.recvfrom(1024)
    print("收到的消息为: ",receive_data.decode())
