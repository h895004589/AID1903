
list = [1,1,1,2,2,6,6,3,4,3]

def fun01(list_target):
    for l in range(len(list_target)-1,-1,-1):
        for i in range(l-1,-1,-1):
            if list_target[l] == list_target[i]:
                del list_target[i]
                break #删除完需要跳出循环防止出现3个的时候把当前的删除
fun01(list)
print(list)