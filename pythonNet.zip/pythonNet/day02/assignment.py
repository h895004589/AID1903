import time
number = 0
fw = open('test.txt', 'a+')
while True:
    local_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
    fw.seek(0,0)
    if len(fw.read()) == 0:
        number = "1"
    else:
        fw.seek(0,0)
        lines = fw.readlines()
        lastline = lines[-1]
        datalist = lastline.split()  # 分割数据,生成列表
        number = int(datalist[0])
        number += 1

    fw.write(str(number)+" "+local_time +'\n')
    time.sleep(1)

