
from socket import *
import struct

ADDR = ("127.0.0.1",8080)

# 规定数据格式
st = struct.Struct('i32sif')

s = socket(AF_INET,SOCK_DGRAM)

while True:
    id = int(input("请输入ID: "))
    name = input("请输入姓名: ").encode()#需要的是字节串
    age = int(input("请输入年龄: "))
    score = float(input("请输入分数: "))

    data = st.pack(id,name,age,score)
    if not data:
        break
    s.sendto(data,ADDR)

s.close()


