
from socket import *

sockfd = socket()

server_addr = ('127.0.0.1',8092)
sockfd.connect(server_addr)

fd = open('assignment.txt','rb')
while True:
    data = (fd.read(1024))
    if not data:
        break
sockfd.send(data)
data = sockfd.recv(1024)
print("From server.jpg: ",data.decode())

sockfd.close()