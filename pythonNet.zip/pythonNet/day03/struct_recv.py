"""
    1.从客户端输入一个学生的 id 姓名 年龄 分数
    2.将其发送到服务器,由服务器写入到一个文件中
    3.每个信息占一行
    4.数据传入使用udp套接字完成
"""
from socket import *
import struct

sockfd = socket(AF_INET,SOCK_DGRAM)

sockfd.bind(("0.0.0.0",8080))

st = struct.Struct('i32sif')

f = open('student.txt','a')

while True:
    data,addr = sockfd.recvfrom(1024)
    #   数据解析
    unpack_data = st.unpack(data)
    if not unpack_data:
        break

    info = "%d %s %d %2f"%(unpack_data[0],unpack_data[1].decode(),unpack_data[2],unpack_data[3])

    f.write(info)

sockfd.close()