import socket

sockfd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sockfd.bind(('0.0.0.0', 8092))
sockfd.listen(5)

print("waiting for connect...")

connfd, addr = sockfd.accept()

fd = open('server.txt', 'wb')
while True:
    data = connfd.recv(1024)
    if not data:
        break
    fd.write(data)

n = connfd.send(b'Receive your message')
print("发送了%d个字节数据" % n)
fd.close()
connfd.close()
sockfd.close()
