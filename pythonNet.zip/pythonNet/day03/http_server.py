"""
    http 功能演示
    将网页发送给浏览器展示
"""

from socket import *

def main():
    sockfd = socket()
    sockfd.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
    sockfd.bind(('0.0.0.0',8080))
    sockfd.listen(3)

    print("Listen the port 8080 ...")
    while True:
        connfd,addr = sockfd.accept()
        handel(connfd)#处理浏览器请求
        connfd.close()

def handel(connfd):
    print("Request from ",connfd.getpeername())
    request = connfd.recv(4096)
    if not request:
        return
    request_line = request.splitlines()[0].decode()
    info = request_line.split(" ")[1]

    if info == '/':
        f = open("index.html")
        respose = "HTTP/1.1 200 OK\r\n"
        respose += "Content-Type:text/html\r\n"
        respose += "\r\n"
        respose += f.read()
    else:
        respose = "HTTP/1.1 404 Not Found\r\n"
        respose += "Content-Type:text/html\r\n"
        respose += "\r\n"
        respose += "<h1>Sorry...</h1>"
    
    connfd.send(respose.encode())

    print(info)

if __name__ == "__main__":
    main()
