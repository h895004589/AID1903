
from socket import *

# 创建tcp套接字

s = socket()
s.bind(("0.0.0.0",8891))
s.listen(3)

c,addr = s.accept()
print("Connect From",addr)
data = c.recv(4096)
print(data)

# http响应格式
data = """HTTP/1.1 200 ok
Content-Type:text/html

<h1>Hello World</h1>
"""

c.send(data.encode())

c.close()
s.close()